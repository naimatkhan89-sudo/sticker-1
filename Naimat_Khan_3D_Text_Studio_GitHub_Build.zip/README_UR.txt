# Naimat Khan 3D Text Studio
Android Kotlin starter project (v1.0).

## موجودہ کام کرنے والے فیچرز
- اردو/پشتو/انگلش زبان کا انتخاب (یہ selector ہے؛ ٹائپنگ کی بورڈ کے ذریعے ہوگی)
- Android Speech Recognizer کے ذریعے voice-to-text؛ زبانوں کی دستیابی فون کے recognizer پر منحصر ہے
- Live 3D-look text preview
- Gold, Blue, Pink, Green, Silver color styles
- 512x512 transparent PNG export to Pictures/NaimatKhan3DTextStudio
- Android share chooser کے ذریعے PNG WhatsApp یا کسی دوسری ایپ میں شیئر کرنا

## WhatsApp Sticker Pack کی حد
یہ ورژن ابھی PNG تصویر کو WhatsApp میں share کرتا ہے؛ اسے WhatsApp کے sticker tray میں باقاعدہ sticker pack کے طور پر add نہیں کرتا۔ اس کے لیے WhatsApp کے official sample API کے مطابق ContentProvider، pack metadata، sticker asset queries، tray icon اور WebP stickers کی مکمل implementation ضروری ہے۔ Official guide: https://github.com/WhatsApp/stickers

## Build on Android phone
AndroidIDE (official docs: https://docs.androidide.com/) میں Open existing project کے ذریعے اس فولڈر کو کھولیں۔ AndroidIDE کے build tools install کریں، Gradle sync ہونے دیں، پھر Run/Build APK کریں۔ اگر Gradle/JDK/SDK incompatibility آئے تو error کا پورا screenshot یا متن بھیجیں۔
