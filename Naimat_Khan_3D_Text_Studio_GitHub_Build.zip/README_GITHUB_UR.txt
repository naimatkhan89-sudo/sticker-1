# GitHub Actions سے موبائل پر APK بنائیں

1. GitHub پر اکاؤنٹ بنائیں/لاگ ان کریں: https://github.com
2. + > New repository منتخب کریں۔ نام: Naimat-Khan-3D-Text-Studio۔ Create repository دبائیں۔
3. ZIP کو فون میں extract کریں۔ GitHub repository میں Add file > Upload files دبائیں۔ ZIP نہیں بلکہ extract کیے ہوئے فولڈر کے اندر کی تمام فائلیں/فولڈرز upload کریں، خاص طور پر app، settings.gradle، build.gradle، gradle.properties اور .github فولڈر۔
4. Commit changes کریں۔
5. Repository میں Actions ٹیب کھولیں۔ اگر workflow enable کرنے کا پیغام آئے تو اسے enable کریں۔
6. "Build Naimat Khan 3D Text Studio APK" workflow کھولیں اور Run workflow دبائیں۔
7. کامیابی کے بعد workflow run کے نیچے Artifacts میں Naimat-Khan-3D-Text-Studio-debug-apk.zip ڈاؤن لوڈ کریں۔
8. Artifact ZIP کو Downloads میں extract کریں۔ app-debug.apk پر ٹیپ کریں اور Install کریں۔ ضرورت ہو تو اس browser/file manager کے لیے Install unknown apps اجازت دیں۔

نوٹ: github.dev صرف code edit/commit کے لیے ہے؛ اس میں terminal یا Android APK build نہیں ہوتا۔ GitHub Actions cloud میں build کرتا ہے۔ Codespaces بھی browser سے terminal/build دے سکتا ہے مگر اس کے استعمال پر quota/billing limits لاگو ہو سکتی ہیں۔

موجودہ ایپ PNG اسٹیکر بناتی اور شیئر کرتی ہے، لیکن WhatsApp کی sticker tray میں باقاعدہ Sticker Pack کے طور پر شامل کرنے والا API integration ابھی مکمل نہیں۔
