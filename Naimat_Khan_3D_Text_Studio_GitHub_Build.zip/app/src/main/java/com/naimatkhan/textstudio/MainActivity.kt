package com.naimatkhan.textstudio

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable
import android.content.ContentValues
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var input: EditText
    private lateinit var preview: TextPreview
    private var selectedColor = 0
    private val colors = listOf(
        intArrayOf(Color.rgb(255,215,90), Color.rgb(255,140,20)),
        intArrayOf(Color.rgb(110,230,255), Color.rgb(20,90,255)),
        intArrayOf(Color.rgb(255,100,190), Color.rgb(150,30,255)),
        intArrayOf(Color.rgb(130,255,160), Color.rgb(0,150,100)),
        intArrayOf(Color.WHITE, Color.LTGRAY)
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(Color.rgb(9,13,24))
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18) }
        val title = TextView(this).apply {
            text="NAIMAT KHAN\n3D TEXT STUDIO"; textSize=25f; gravity=Gravity.CENTER
            setTextColor(Color.rgb(255,215,100)); setPadding(8,12,8,4)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text="PREMIUM 3D  •  NEON"; textSize=12f; gravity=Gravity.CENTER
            setTextColor(Color.CYAN); setPadding(4,0,4,14)
        }
        root.addView(subtitle)
        val lang = Spinner(this)
        lang.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("اردو (Urdu)","پشتو (Pashto)","English"))
        root.addView(lang)
        input=EditText(this).apply {
            hint="یہاں اپنا نام یا عبارت لکھیں…"; textSize=21f; setTextColor(Color.WHITE)
            setHintTextColor(0xFF9AA7C0.toInt()); setPadding(14,12,14,12)
            background=rounded(0xFF1B263B.toInt(),0xFFB88A35.toInt())
            minLines=2
        }
        root.addView(input, LinearLayout.LayoutParams(-1,-2).apply { topMargin=14 })
        val mic=button("🎙  بول کر لکھیں")
        mic.setOnClickListener {
            val locale = when(lang.selectedItemPosition) { 0->"ur-PK"; 1->"ps-AF"; else->"en-US" }
            if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),11)
            } else startSpeech(locale)
        }
        root.addView(mic)
        preview=TextPreview(this)
        root.addView(preview,LinearLayout.LayoutParams(-1,250).apply { topMargin=14 })
        input.addTextChangedListener(SimpleWatcher { preview.value=it; preview.invalidate() })
        val colorRow=LinearLayout(this).apply { gravity=Gravity.CENTER; orientation=LinearLayout.HORIZONTAL }
        listOf("GOLD","BLUE","PINK","GREEN","SILVER").forEachIndexed { i,s ->
            val b=Button(this).apply { text=s; textSize=9f; setTextColor(Color.WHITE); setBackgroundColor(colors[i][0]) }
            b.setOnClickListener { selectedColor=i; preview.palette=colors[i]; preview.invalidate() }
            colorRow.addView(b,LinearLayout.LayoutParams(0,48,1f).apply { setMargins(2,8,2,8) })
        }
        root.addView(colorRow)
        val save=button("⬇  3D اسٹیکر محفوظ کریں")
        save.setOnClickListener { saveSticker() }
        root.addView(save)
        val add=button("＋  WhatsApp میں شامل کریں")
        add.setOnClickListener { addToWhatsApp() }
        root.addView(add)
        val note=TextView(this).apply {
            text="پہلے اسٹیکر محفوظ کریں، پھر WhatsApp میں شامل کریں۔\nاسٹیکر پیک انضمام کے لیے WhatsApp کی مطابقت اور درست پیک میٹا ڈیٹا درکار ہے۔"
            textSize=11f; setTextColor(0xFF9AA7C0.toInt()); gravity=Gravity.CENTER; setPadding(8,12,8,0)
        }
        root.addView(note)
        val scroll=ScrollView(this); scroll.addView(root); setContentView(scroll)
    }
    private fun rounded(color:Int,stroke:Int)=GradientDrawable().apply {
        setColor(color); cornerRadius=22f; setStroke(2,stroke)
    }
    private fun button(label:String)=Button(this).apply {
        text=label; textSize=15f; setTextColor(Color.WHITE)
        background=rounded(0xFF17243A.toInt(),0xFF00DDF5.toInt())
        isAllCaps=false
        layoutParams=LinearLayout.LayoutParams(-1,56).apply { topMargin=10 }
    }
    private fun startSpeech(locale:String) {
        try {
            val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE,locale)
                putExtra(RecognizerIntent.EXTRA_PROMPT,"اب بولیں")
            }
            startActivityForResult(i,22)
        } catch(e:Exception) { Toast.makeText(this,"اس موبائل میں Speech Recognition دستیاب نہیں",Toast.LENGTH_LONG).show() }
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==22 && resultCode==RESULT_OK) {
            val spoken=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.append(if(input.text.isNullOrEmpty()) spoken else " $spoken")
        }
    }
    private fun saveSticker(): android.net.Uri? {
        val text=input.text.toString().trim()
        if(text.isEmpty()) { Toast.makeText(this,"پہلے ٹیکسٹ لکھیں",Toast.LENGTH_SHORT).show(); return null }
        val bitmap=Bitmap.createBitmap(512,512,Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bitmap); canvas.drawColor(Color.TRANSPARENT,PorterDuff.Mode.CLEAR)
        val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign=Paint.Align.CENTER; typeface=Typeface.create("sans-serif",Typeface.BOLD); textSize=58f
            setShadowLayer(10f,0f,0f,Color.CYAN); style=Paint.Style.FILL }
        val lines=wrap(text,12)
        val lineH=68f; var y=256f-(lines.size-1)*lineH/2
        lines.forEach { line ->
            p.color=Color.BLACK; p.style=Paint.Style.STROKE; p.strokeWidth=12f; canvas.drawText(line,256f,y+5,p)
            p.style=Paint.Style.FILL
            val shader=LinearGradient(0f,y-55f,0f,y+10f,colors[selectedColor][0],colors[selectedColor][1],Shader.TileMode.CLAMP)
            p.shader=shader; canvas.drawText(line,256f,y,p); p.shader=null; y+=lineH
        }
        val values=ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME,"NaimatSticker_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE,"image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/NaimatKhan3DTextStudio")
        }
        val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)
        if(uri==null) { Toast.makeText(this,"تصویر محفوظ نہیں ہو سکی",Toast.LENGTH_LONG).show(); return null }
        try {
            contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) }
        } catch(e:Exception) {
            contentResolver.delete(uri,null,null)
            Toast.makeText(this,"محفوظ کرنے میں مسئلہ: ${e.message}",Toast.LENGTH_LONG).show()
            return null
        }
        Toast.makeText(this,"PNG اسٹیکر Pictures/NaimatKhan3DTextStudio میں محفوظ ہوگیا",Toast.LENGTH_LONG).show()
        return uri
    }
    private fun wrap(s:String,max:Int):List<String> {
        val out= mutableListOf<String>(); var line=""
        s.split(" ").forEach { w -> if(line.length+w.length>max && line.isNotEmpty()){out.add(line);line=w}else line=if(line.isEmpty())w else "$line $w" }
        if(line.isNotEmpty()) out.add(line); return out
    }
    private fun addToWhatsApp() {
        val uri=saveSticker() ?: return
        val share=Intent(Intent.ACTION_SEND).apply {
            type="image/png"; putExtra(Intent.EXTRA_STREAM,uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(Intent.createChooser(share,"WhatsApp یا دوسری ایپ میں شیئر کریں")) }
        catch(e:Exception) { Toast.makeText(this,"شیئر کرنے والی ایپ دستیاب نہیں",Toast.LENGTH_LONG).show() }
    }
}
class TextPreview(c:android.content.Context):View(c) {
    var value="نعمت خان"
    var palette=intArrayOf(Color.rgb(255,215,90),Color.rgb(255,140,20))
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c:Canvas) {
        super.onDraw(c); c.drawColor(0xFF111A2B.toInt())
        p.textAlign=Paint.Align.CENTER; p.typeface=Typeface.create("sans-serif",Typeface.BOLD)
        p.textSize=if(value.length>16)34f else 48f
        p.setShadowLayer(12f,0f,0f,Color.CYAN); p.color=Color.BLACK; p.style=Paint.Style.STROKE; p.strokeWidth=9f
        val x=width/2f; val y=height/2f
        c.drawText(value,x,y+5,p)
        p.style=Paint.Style.FILL; p.shader=LinearGradient(0f,y-55f,0f,y+8f,palette[0],palette[1],Shader.TileMode.CLAMP)
        c.drawText(value,x,y,p); p.shader=null; p.clearShadowLayer()
        p.color=Color.CYAN; p.style=Paint.Style.STROKE; p.strokeWidth=2f
        c.drawRoundRect(8f,8f,width-8f,height-8f,22f,22f,p); p.style=Paint.Style.FILL
    }
}
class SimpleWatcher(val changed:(String)->Unit):android.text.TextWatcher {
    override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
    override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){changed(s?.toString().orEmpty())}
    override fun afterTextChanged(s:android.text.Editable?){}
}
